import Header from "@/components/Header";
import CourseCard from "@/components/CourseCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";

const Courses = () => {
  const courses = [
    {
      id: "1",
      title: "Complete Web Development Bootcamp",
      instructor: "Dr. Angela Yu",
      thumbnail: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
      price: 84.99,
      rating: 4.8,
      students: 45230,
      duration: "52h",
      level: "Beginner",
    },
    {
      id: "2",
      title: "Machine Learning A-Z: Hands-On Python",
      instructor: "Kirill Eremenko",
      thumbnail: "https://images.unsplash.com/photo-1555949963-aa79dcee981c",
      price: 94.99,
      rating: 4.9,
      students: 38450,
      duration: "44h",
      level: "Intermediate",
    },
    {
      id: "3",
      title: "The Complete Digital Marketing Course",
      instructor: "Rob Percival",
      thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f",
      price: 79.99,
      rating: 4.7,
      students: 29340,
      duration: "38h",
      level: "All Levels",
    },
    {
      id: "4",
      title: "iOS Development with Swift",
      instructor: "Angela Yu",
      thumbnail: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c",
      price: 89.99,
      rating: 4.8,
      students: 32100,
      duration: "48h",
      level: "Beginner",
    },
    {
      id: "5",
      title: "Data Science Masterclass",
      instructor: "Jose Portilla",
      thumbnail: "https://images.unsplash.com/photo-1551288049-bebda4e38f71",
      price: 99.99,
      rating: 4.9,
      students: 41200,
      duration: "56h",
      level: "Advanced",
    },
    {
      id: "6",
      title: "Graphic Design Masterclass",
      instructor: "Lindsay Marsh",
      thumbnail: "https://images.unsplash.com/photo-1561070791-2526d30994b5",
      price: 74.99,
      rating: 4.7,
      students: 28900,
      duration: "40h",
      level: "Beginner",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Search and Filter Section */}
        <section className="border-b bg-muted/30 py-8">
          <div className="container">
            <h1 className="text-3xl md:text-4xl font-bold mb-6">Explore Courses</h1>
            
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search for courses..."
                  className="pl-10 h-12"
                />
              </div>
              
              <Select defaultValue="all">
                <SelectTrigger className="w-full md:w-48 h-12">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="development">Development</SelectItem>
                  <SelectItem value="design">Design</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="business">Business</SelectItem>
                </SelectContent>
              </Select>
              
              <Select defaultValue="popular">
                <SelectTrigger className="w-full md:w-48 h-12">
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="popular">Most Popular</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                </SelectContent>
              </Select>
              
              <Button className="btn-gradient h-12 w-full md:w-auto">
                Apply Filters
              </Button>
            </div>
          </div>
        </section>

        {/* Courses Grid */}
        <section className="py-12">
          <div className="container">
            <div className="mb-6 flex items-center justify-between">
              <p className="text-muted-foreground">
                Showing {courses.length} results
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => (
                <CourseCard key={course.id} {...course} />
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-12 mt-auto">
        <div className="container">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 EduLearn. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Courses;
