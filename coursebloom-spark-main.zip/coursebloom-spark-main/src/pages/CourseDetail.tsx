import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Star, Clock, Users, Globe, Award, PlayCircle, 
  CheckCircle, BookOpen, TrendingUp 
} from "lucide-react";

const CourseDetail = () => {
  const { id } = useParams();

  // Sample course data
  const course = {
    title: "Complete Web Development Bootcamp",
    instructor: "Dr. Angela Yu",
    thumbnail: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
    price: 84.99,
    rating: 4.8,
    students: 45230,
    duration: "52h",
    level: "Beginner",
    language: "English",
    description: "Become a full-stack web developer with just one course. HTML, CSS, JavaScript, Node, React, MongoDB, and more!",
    whatYouLearn: [
      "Build 16 web development projects for your portfolio",
      "Learn the latest technologies including React, Node.js, and MongoDB",
      "Build fully-fledged websites and web apps for your business",
      "Master frontend and backend development",
    ],
    curriculum: [
      { title: "Introduction to Web Development", lessons: 12, duration: "2h 30m" },
      { title: "HTML 5 Fundamentals", lessons: 15, duration: "3h 15m" },
      { title: "CSS 3 and Flexbox", lessons: 18, duration: "4h 20m" },
      { title: "JavaScript Basics", lessons: 25, duration: "6h 45m" },
      { title: "Advanced JavaScript", lessons: 20, duration: "5h 30m" },
      { title: "React.js Framework", lessons: 30, duration: "8h 15m" },
    ],
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative bg-muted/30 border-b">
          <div className="container py-12">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Badge className="mb-4">{course.level}</Badge>
                <h1 className="text-3xl md:text-4xl font-bold mb-4">{course.title}</h1>
                <p className="text-lg text-muted-foreground mb-6">{course.description}</p>
                
                <div className="flex flex-wrap items-center gap-6 text-sm mb-6">
                  <div className="flex items-center space-x-2">
                    <Star className="h-5 w-5 fill-warning text-warning" />
                    <span className="font-semibold">{course.rating}</span>
                    <span className="text-muted-foreground">({course.students.toLocaleString()} students)</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-5 w-5" />
                    <span>{course.duration} total</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Globe className="h-5 w-5" />
                    <span>{course.language}</span>
                  </div>
                </div>

                <p className="text-muted-foreground">
                  Created by <span className="text-primary font-medium">{course.instructor}</span>
                </p>
              </div>

              {/* Course Card */}
              <div className="lg:col-span-1">
                <Card className="sticky top-20 shadow-xl">
                  <CardContent className="p-0">
                    <div className="relative">
                      <img
                        src={course.thumbnail}
                        alt={course.title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 rounded-t-lg">
                        <PlayCircle className="h-16 w-16 text-white" />
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="text-3xl font-bold mb-4">${course.price}</div>
                      <Button className="btn-gradient w-full mb-3" size="lg">
                        Enroll Now
                      </Button>
                      <Button variant="outline" className="w-full" size="lg">
                        Add to Wishlist
                      </Button>
                      <div className="mt-6 space-y-3 text-sm">
                        <div className="flex items-center space-x-2">
                          <CheckCircle className="h-5 w-5 text-success" />
                          <span>30-Day Money-Back Guarantee</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Award className="h-5 w-5 text-success" />
                          <span>Certificate of Completion</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <TrendingUp className="h-5 w-5 text-success" />
                          <span>Lifetime Access</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Course Content */}
        <section className="py-12">
          <div className="container">
            <div className="max-w-4xl">
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-8">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                  <TabsTrigger value="instructor">Instructor</TabsTrigger>
                </TabsList>
                
                <TabsContent value="overview" className="space-y-6">
                  <div>
                    <h2 className="text-2xl font-bold mb-4">What you'll learn</h2>
                    <div className="grid md:grid-cols-2 gap-4">
                      {course.whatYouLearn.map((item, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <CheckCircle className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h2 className="text-2xl font-bold mb-4">Course Description</h2>
                    <p className="text-muted-foreground leading-relaxed">
                      {course.description} This comprehensive course will take you from beginner 
                      to advanced level, covering everything you need to know to become a professional 
                      web developer. You'll build real-world projects and gain hands-on experience 
                      with the latest technologies.
                    </p>
                  </div>
                </TabsContent>

                <TabsContent value="curriculum" className="space-y-4">
                  <h2 className="text-2xl font-bold mb-6">Course Curriculum</h2>
                  {course.curriculum.map((section, index) => (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10">
                              <BookOpen className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <h3 className="font-semibold">{section.title}</h3>
                              <p className="text-sm text-muted-foreground">
                                {section.lessons} lessons • {section.duration}
                              </p>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm">Preview</Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="instructor">
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4 mb-4">
                        <div className="w-20 h-20 rounded-full bg-gradient-primary" />
                        <div>
                          <h3 className="text-xl font-bold mb-2">{course.instructor}</h3>
                          <p className="text-muted-foreground mb-4">
                            Lead Instructor & Web Development Expert
                          </p>
                          <div className="flex items-center space-x-6 text-sm">
                            <div className="flex items-center space-x-2">
                              <Star className="h-4 w-4 fill-warning text-warning" />
                              <span>4.8 Instructor Rating</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Users className="h-4 w-4" />
                              <span>250K Students</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <p className="text-muted-foreground">
                        With over 10 years of experience in web development and teaching, 
                        I've helped thousands of students launch their careers in tech. 
                        My courses focus on practical, real-world skills that employers are looking for.
                      </p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-12 mt-auto">
        <div className="container">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 EduLearn. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default CourseDetail;
