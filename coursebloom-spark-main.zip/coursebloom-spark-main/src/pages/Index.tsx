import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import CourseCard from "@/components/CourseCard";
import { ArrowRight, BookOpen, Trophy, Users, Zap } from "lucide-react";

const Index = () => {
  // Sample course data
  const featuredCourses = [
    {
      id: "1",
      title: "Complete Web Development Bootcamp",
      instructor: "Dr. Angela Yu",
      thumbnail: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
      price: 84.99,
      rating: 4.8,
      students: 45230,
      duration: "52h",
      level: "Beginner",
    },
    {
      id: "2",
      title: "Machine Learning A-Z: Hands-On Python",
      instructor: "Kirill Eremenko",
      thumbnail: "https://images.unsplash.com/photo-1555949963-aa79dcee981c",
      price: 94.99,
      rating: 4.9,
      students: 38450,
      duration: "44h",
      level: "Intermediate",
    },
    {
      id: "3",
      title: "The Complete Digital Marketing Course",
      instructor: "Rob Percival",
      thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f",
      price: 79.99,
      rating: 4.7,
      students: 29340,
      duration: "38h",
      level: "All Levels",
    },
  ];

  const stats = [
    { icon: Users, label: "Active Students", value: "500K+" },
    { icon: BookOpen, label: "Courses Available", value: "2,500+" },
    { icon: Trophy, label: "Certified Learners", value: "350K+" },
    { icon: Zap, label: "Hours of Content", value: "50K+" },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 gradient-hero opacity-10" />
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent gradient-hero">
              Learn Without Limits
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8">
              Discover thousands of courses from expert instructors. Build skills with our
              hands-on learning approach.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="btn-gradient text-lg">
                <Link to="/courses">
                  Explore Courses <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="text-lg border-2">
                <Link to="/auth">Start Teaching</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-muted/30">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="text-center animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg gradient-primary mb-3">
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div className="text-3xl font-bold mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Courses</h2>
            <p className="text-lg text-muted-foreground">
              Handpicked courses to help you achieve your learning goals
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {featuredCourses.map((course) => (
              <CourseCard key={course.id} {...course} />
            ))}
          </div>

          <div className="text-center">
            <Button asChild size="lg" variant="outline" className="border-2">
              <Link to="/courses">
                View All Courses <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 gradient-secondary opacity-10" />
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Start Your Learning Journey?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join millions of students already learning on EduLearn
            </p>
            <Button asChild size="lg" className="btn-gradient text-lg">
              <Link to="/auth">
                Get Started Today <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 mt-auto">
        <div className="container">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 EduLearn. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
