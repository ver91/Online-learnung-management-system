import Header from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Award, TrendingUp, Clock, PlayCircle } from "lucide-react";
import { Link } from "react-router-dom";

const Dashboard = () => {
  const enrolledCourses = [
    {
      id: "1",
      title: "Complete Web Development Bootcamp",
      thumbnail: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
      progress: 65,
      lastWatched: "Introduction to React Hooks",
      totalLessons: 120,
      completedLessons: 78,
    },
    {
      id: "2",
      title: "Machine Learning A-Z",
      thumbnail: "https://images.unsplash.com/photo-1555949963-aa79dcee981c",
      progress: 30,
      lastWatched: "Linear Regression Models",
      totalLessons: 95,
      completedLessons: 28,
    },
  ];

  const stats = [
    { icon: BookOpen, label: "Enrolled Courses", value: "8", color: "text-primary" },
    { icon: Award, label: "Completed", value: "3", color: "text-success" },
    { icon: TrendingUp, label: "In Progress", value: "5", color: "text-warning" },
    { icon: Clock, label: "Hours Learned", value: "127", color: "text-secondary" },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 bg-muted/30">
        <div className="container py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Welcome back, Student!</h1>
            <p className="text-muted-foreground">Continue your learning journey</p>
          </div>

          {/* Stats Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <Card key={index} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                      <p className="text-3xl font-bold">{stat.value}</p>
                    </div>
                    <div className={`p-3 rounded-lg bg-muted ${stat.color}`}>
                      <stat.icon className="h-6 w-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Course Progress */}
          <Tabs defaultValue="enrolled" className="space-y-6">
            <TabsList>
              <TabsTrigger value="enrolled">My Courses</TabsTrigger>
              <TabsTrigger value="wishlist">Wishlist</TabsTrigger>
              <TabsTrigger value="certificates">Certificates</TabsTrigger>
            </TabsList>

            <TabsContent value="enrolled" className="space-y-4">
              {enrolledCourses.map((course) => (
                <Card key={course.id} className="card-hover">
                  <CardContent className="p-0">
                    <div className="grid md:grid-cols-4 gap-6 p-6">
                      <div className="relative group cursor-pointer">
                        <img
                          src={course.thumbnail}
                          alt={course.title}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                        <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity">
                          <PlayCircle className="h-12 w-12 text-white" />
                        </div>
                      </div>
                      
                      <div className="md:col-span-3 flex flex-col justify-between">
                        <div>
                          <h3 className="font-bold text-lg mb-2">{course.title}</h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            Last watched: {course.lastWatched}
                          </p>
                          
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">
                                {course.completedLessons} of {course.totalLessons} lessons completed
                              </span>
                              <span className="font-semibold">{course.progress}%</span>
                            </div>
                            <Progress value={course.progress} className="h-2" />
                          </div>
                        </div>
                        
                        <div className="flex gap-3 mt-4">
                          <Button asChild className="btn-gradient">
                            <Link to={`/course/${course.id}`}>Continue Learning</Link>
                          </Button>
                          <Button variant="outline">
                            View Certificate
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="wishlist">
              <Card>
                <CardHeader>
                  <CardTitle>Your Wishlist</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-center py-8">
                    No courses in your wishlist yet. Start exploring!
                  </p>
                  <div className="text-center">
                    <Button asChild className="btn-gradient">
                      <Link to="/courses">Browse Courses</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="certificates">
              <Card>
                <CardHeader>
                  <CardTitle>Your Certificates</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-center py-8">
                    Complete a course to earn your first certificate!
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <footer className="border-t py-12 mt-auto">
        <div className="container">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2025 EduLearn. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Dashboard;
